import { useEffect } from "react";
import { getFiveDayWeather } from "../services/weather-service";
import { useState } from "react";
import React from "react";
import { Link } from "react-router-dom";

const WeatherFiveDay = () => {

    const [weatherFive, setWeatherFive] = useState([])
    const weekday = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];


    useEffect(()=>{
        const getData = async() => {
            const response = await getFiveDayWeather();
            const data = response.list.filter((w)=>w.dt_txt.includes("00:00:00"))
            setWeatherFive(data)
            console.log(data)
        }
        getData()

    },[]

    )

    return(
        <>
            {weatherFive.map((weather) => {
                return(
                    <Link className="text-decoration-none" to={`/${weather.dt_txt.split(" ")[0]}`}>
                        <div className="row m-3 border border-1 w-50 " key={weather.dt}>
                        
                            
                                <div className="col-2 mt-2">
                                    <div>{(weather.weather[0].main === "Clear")?<i class="bi bi-brightness-high-fill"></i>: ((weather.weather[0].main === "Clouds")?<i class="bi bi-cloud-fill"></i>:(weather.weather[0].main === "Rain")?<i class="bi bi-cloud-rain-fill"></i>:((weather.weather[0].main === "Snow")?<i class="bi bi-cloud-rain-fill"></i>:<i class="bi bi-brightness-high-fill"></i>))}</div>                           
                                 
                                </div>
                                <div className="col-6">
                                    <div className="row">
                                        <div className="col-5">{weather.dt_txt.split(" ")[0]}</div>
                                        <div className="col-5">{weekday[new Date(weather.dt_txt).getDay()]}</div>
                                    </div>
                                     <div className="row">
                                        <div className="col-5">Max: {weather.main.temp_max}</div>
                                        <div className="col-5">min: {weather.main.temp_min}</div> 
                                     </div>
                                    
                                </div>
                                
                          
                        </div>
                                                       
                    </Link>
                    )
            })}
        </>
       
          
    )
}

export default WeatherFiveDay;