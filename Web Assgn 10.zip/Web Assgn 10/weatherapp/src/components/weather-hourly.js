import { useState,useEffect } from "react";
import { useParams } from "react-router";
import { getFiveDayWeather } from "../services/weather-service";


const WeatherHourly = () => {
    const {day} = useParams();
    const [hourlyData, setHourlyData] = useState([]);
    const date = new Date(day + " " + "00:00:00");
    console.log(date.getDay())
    const weekday = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];

    useEffect(()=>{
        const getData = async() => {
            const response = await getFiveDayWeather();
            const data = response.list.filter((w)=>w.dt_txt.includes(day))
            console.log(data)
            setHourlyData(data)
        }
        getData()
    
    },[])

    return(
        <>
                                      
            <div className="row">{weekday[date.getDay()]} ({day})</div> 
            <div className="row">
                    <div className="col-2 border border-1"><b>Time</b></div>
                <div className="col-3 border border-1"><b>Temperature</b></div>
            </div>

            {
            hourlyData.map((weather) => {
                return(
                        <div className="row" key={weather.dt}>

                            <div className="col-2 border border-1">{weather.dt_txt.split(" ")[1]}</div>
                            <div className="col-3 border border-1">{weather.main.temp}</div>
                            
                        
                        </div>
                    )
            })
            }
        </>
    )
}

export default WeatherHourly;