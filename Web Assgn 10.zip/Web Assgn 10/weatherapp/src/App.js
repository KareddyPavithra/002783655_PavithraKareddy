import logo from './logo.svg';
import './App.css';
import { BrowserRouter } from 'react-router-dom';
import {Routes, Route} from 'react-router';
import WeatherFiveDay from './components/weatherfiveday';
import WeatherHourly from './components/weather-hourly';

function App() {
  return (
    <div className="App">
      <div className="container">
        <h1 className="text-success"> Weather Forecast</h1>
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<WeatherFiveDay/>}/>
            <Route path="/:day" element={<WeatherHourly/>}/>
          </Routes>
        </BrowserRouter>
      </div>
      
      
      
    </div>
  );
}

export default App;
