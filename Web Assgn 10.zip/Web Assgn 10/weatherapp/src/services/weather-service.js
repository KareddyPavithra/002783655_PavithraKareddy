
import axios from 'axios'

const API_BASE = 'http://api.openweathermap.org/data/2.5/forecast?q=Boston&appid=7c477a4f4b0b96115fee3e5132c9dc5b'
export const getFiveDayWeather = async () => {
    const response = await axios.get(API_BASE)
    return response.data
}