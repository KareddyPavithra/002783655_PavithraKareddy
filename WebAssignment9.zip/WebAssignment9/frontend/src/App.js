import './App.css';
import React, { useState } from 'react';
import {BrowserRouter as Router, Routes, Route} from 'react-router-dom'
import LoginPage from './App/Login/LoginPage';
import MainPage from './App/Main/MainPage';

import About from './App/pages/About';
import Jobs from './App/pages/Jobs'
import Home from './App/pages/Home';
import Profile from './App/pages/Profile'


function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(() => {
    const localUser = localStorage.getItem("user");
    return localUser !== null;
  });

  function handleLogin(){
    setIsLoggedIn(true);
  }

  return (
    <Router>
      {isLoggedIn && <MainPage/>}
      <Routes>
        <Route path='/user/login' element={<LoginPage handle= {handleLogin}/>}></Route>
        {isLoggedIn &&
          <>
          <Route path='/home' element={<Home/>}></Route>
          <Route path='/about' element={<About/>}></Route>
          <Route path='/jobs' element={<Jobs/>}></Route>
          <Route path='/profile' element={<Profile/>}></Route>
          </>
        }
      </Routes>
    </Router>
  );
}

export default App;
