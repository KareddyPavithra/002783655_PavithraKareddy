import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import "./LoginPage.css"

export default function LoginPage({...props}){
    const navigate = useNavigate();

    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [error, setError] = useState("");

    const loginOptions = [
        {
            socialMedia: 'Google', links: 'https://accounts.google.com/v3/signin/identifier?dsh=S2131487609%3A1680195933082169&ifkv=AQMjQ7Sn0boXT0TiGLF_O7GKX_isKOmtDeHHO5QM6XkMH0ocppJB4CMwb3rY5JVaM3sS8coFOH8b&flowName=GlifWebSignIn&flowEntry=ServiceLogin'

        },
        {
            socialMedia: 'Facebook', links: 'https://www.facebook.com/login/'
        },
    ];

    const handleButtonClick = (links) => {
        window.open(links, '_blank');
    };

    const handleSubmit = async (event) => {
        event.preventDefault();
        try {
            const response = await axios.post("http://localhost:3000/user/login", { email, password });
            if (response.data.exist) {
                localStorage.setItem("user", JSON.stringify(response.data.user));
                props.handle();
                navigate('/main');
            } else {
                setError(response.data.message);
            }
        } catch (error) {
            console.error(error);
            setError("An unexpected error occurred");
        }
    }
    

    return(
        <div className="login-page">
            <h1> Login Page</h1>
            <form onSubmit={handleSubmit}>
                <label>
                    Email:
                    <input type="email" className="login-input" value={email} onChange={event => setEmail(event.target.value)} required />
                </label>
                <br/>
                <label>
                    Password:
                    <input type="password" className="login-input" value={password} onChange={event => setPassword(event.target.value)} required />
                </label>
                <br/>
                {error && <p className="error-message">{error}</p>}
                <button type="submit" className="login-button">Sign In</button>
                {loginOptions.map((link) => (
                    <button key={link.socialMedia} className="login-button" onClick={(e) => {
                        e.preventDefault();
                        handleButtonClick(link.links);
                    }}
                >
                    {link.socialMedia}
                </button>
                ))}
            </form>
        </div>
    )
}
