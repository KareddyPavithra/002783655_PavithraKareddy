import React from "react";
import J from './Images/down-arrow.png';
function Jobs(props){
    return (
        <div className="col">
            <div className="card " style={{boxShadow: "0 4px 8px 0 rgba(0, 0, 0, 0.2)", maxWidth: "400px", margin: "auto", textAlign: "center", fontFamily: "arial"}}>
            <img src={J} style={{height: "200px", width: "100%"}} alt="dropdown" />
            <div className="card-body" style={{padding: "20px"}}>
                <h5 className="card-title" style={{fontSize: "24px", marginBottom: "10px"}}>Drop your Experiences</h5>
                <p className="card-text" style={{fontSize: "16px", marginBottom: "20px"}}>If you would like to join our fantastic team in travelling, guiding and more, share your resume via the given link</p>
                <a href="https://www.google.com/" className="btn btn-primary" style={{backgroundColor: "#007bff", color: "#fff", padding: "10px 20px", borderRadius: "5px", textDecoration: "none"}}>Click Here</a>
            </div>
            </div>
        </div>
        
      );
}

export default Jobs 