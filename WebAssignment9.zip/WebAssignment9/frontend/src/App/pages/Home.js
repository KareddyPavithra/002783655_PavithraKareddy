import React from 'react';
import homeImage from "../pages/Images/home.png";

const Card = ({ title, image, text }) => {
  return (
    <div className="card">
      <img src={image} alt={title} style={{height:"200px", display:'flex', marginLeft:'500px'}}/>
      <h2 style={{marginLeft:'500px'}}>{title}</h2>
      <p style={{marginLeft:'500px'}}>{text}</p>
    </div>
  );
};

const CardRow = () => {
  return (
    <div className="card-row">
      <Card
        title="Home"
        image={homeImage}
        text="Welcome to the Home Page"
      />
    
      
    </div>
  );
};

const App = () => {
  return (
    <div className="app">
      <CardRow />
    </div>
  );
};

export default App;
