import React from "react";
import J from './Images/travel.png'
function About(props){
    return (
        <div className="col" style={{backgroundColor:'lavender'}}>
            <div className="card " style={{boxShadow: "0 4px 8px 0 rgba(0, 0, 0, 0.2)", maxWidth: "400px", margin: "auto", textAlign: "center", fontFamily: "arial"}}>
            <img src={J} style={{height: "300px", width: "80%"}} alt="travelling"/>
            <div className="card-body" style={{padding: "20px"}}>
                <h5 className="card-title" style={{fontSize: "24px", marginBottom: "10px"}}>Explore the world with us.</h5>
                <p className="card-text" style={{fontSize: "16px", marginBottom: "20px"}}>Check out amazing blogs posted by our travellers on the link below</p>
                <a href="https://www.google.com/" className="btn btn-primary" style={{backgroundColor: "#007bff", color: "#fff", padding: "10px 20px", borderRadius: "5px", textDecoration: "none"}}>Click Here</a>
            </div>
            </div>

           

        </div>
        
      );
}

export default About