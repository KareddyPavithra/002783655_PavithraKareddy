import React from 'react';
import phn from './Images/telephone.png';
import gmailImg from './Images/gmail.png';

const Card = ({ title, image, text }) => {
  return (
    <div className="card">
      <img src={image} alt={title} style={{height:'200px', width:'50%'}} />
      <h2 style={{justifyContent:'center'}}>{title}</h2>
      <p>{text}</p>
    </div>
  );
};

const CardRow = () => {
  return (
    <div className="card-row" style={{display:'flex', justifyContent:'center', gap:'1rem'}}>
      <div className='card'>
      <Card
        title="Contact Info"
        image={phn}
        text="You can contact us via phone or mail by clicking on any of the above"
      />
      </div>
      <div className='card' style={{width:'40%'}}>
      <Card
        title=""
        image={gmailImg}
      />
      </div>
    </div>
  );
};

const App = () => {
  return (
    <div className="app">
      <CardRow />
    </div>
  );
};

export default App;

